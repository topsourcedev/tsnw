
var ApiGen = ApiGen || {};
ApiGen.elements = [["f","autoload()"],["c","Autoloader"],["c","baseController"],["c","blogController"],["c","Database"],["c","error404Controller"],["c","Exception"],["c","indexController"],["c","inspectorController"],["c","Registry"],["c","robertoepaoloController"],["c","router"],["c","Template"],["c","WolfMVC\\ArrayMethods"],["c","WolfMVC\\Base"],["c","WolfMVC\\Configuration"],["c","WolfMVC\\Inspector"],["c","WolfMVC\\StringMethods"]];
